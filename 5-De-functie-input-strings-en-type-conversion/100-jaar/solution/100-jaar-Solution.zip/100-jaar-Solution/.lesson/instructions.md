# 100 jaar

Je schrijft een programma dat het volgende realiseert:
1. **Input**: vraag aan de gebruiker hun naam en leeftijd. Hiervoor gebruik je de inputfunctie. Deze informatie ken je toe aan variabelen.
2. **Berekeningen 1**: bereken in welk jaar de gebruiker 100 jaar zal worden. Ken de berekende waarde toe aan een variabele.
3. **Berekeningen 2**: bereken hoeveel jaar de gebruiker nog heeft totdat deze 100 jaar wordt.
4. **Output**: toon een gepersonaliseerd bericht voor de gebruiker, door middel van de printfunctie en f-strings, in de uitvoer. Dit bericht bevat de naam, huidige leeftijd, het jaar dat zij 100 worden en het aantal jaren zij nog hebben totdat ze 100 jaar zijn.

## Een voorbeeld van de output
```cli
Wat is je naam? Indy
Wat is je leeftijd? 25
Dag Indy, je bent momenteel 25 jaar oud.
Je wordt 100 jaar in het jaar 2098.
Je hebt nog 75 jaar totdat je 100 jaar bent.
```

## Criteria
- Gebruik correcte benamingen voor je variabelen.
- Maak gebruik van *type conversion* om inputgegevens om te zetten naar gehele getallen.
- Maak gebruik van de geziene functies: input, print, f-strings.
- In de uitvoer verschijnen volzinnen, beginnend met een hoofdletter en eindigend met een leesteken.