naam = input("Naam: ")
leeftijd = int(input("Leeftijd: "))

jaar_100 = 100 - leeftijd + 2023
jaren_tot_100 = 100 - leeftijd

print(f"Dag {naam}, je bent momenteel {leeftijd} jaar oud.")
print(f"Je wordt 100 jaar in het jaar {jaar_100}.")
print(f"Je hebt nog {jaren_tot_100} jaar totdat je 100 jaar bent.")