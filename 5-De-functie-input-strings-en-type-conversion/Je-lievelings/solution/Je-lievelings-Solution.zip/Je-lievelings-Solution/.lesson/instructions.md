# Je lievelings...
Schrijf een programma waarin je aan een gebruiker hun lievelingskleur, -eten en -reisbestemming vraagt. In de uitvoer worden drie volzinnen getoond waarin de lievelingszaken van de gebruiker opgesomd worden.

## Stappenplan
1. Maak drie variabelen aan, één voor de lievelingskleur, één voor het lievelingseten en één voor de lievelingsreisbestemming.
2. Bij elke variabele maak je gebruik van de inputfunctie en vraag je naar de lievelingszaken, bv. "Wat is je lievelingskleur? "
3. Gebruik drie keer de prinfunctie om in de uitvoer de onderstaande volzinnen te tonen:
* Je lievelingskleur is *kleur*.
* Je eet het liefst vanal *eten*.
* Je favoriete reisbestemming is *bestemming*.
4. Klik ten slotte op **submit**.

## Tip
De uitvoer moet **exact** overeenkomen de voorbeeldzinnen die hierboven staan.