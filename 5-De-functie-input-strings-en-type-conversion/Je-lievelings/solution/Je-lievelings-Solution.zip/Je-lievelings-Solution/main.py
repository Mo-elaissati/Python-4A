# We vragen drie keer naar specifieke gegevens:
kleur = input("Wat is je lievelingskleur? ")
eten = input("Wat is je lievelingseten? ")
bestemming = input("Wat is je favoriete reisbestemming? ")

# We zetten de variabelen in een f-string zodat we volzinnen kunnen formuleren:
print(f"Je lievelingskleur is {kleur}.")
print(f"Je eet het liefst vanal {eten}.")
print(f"Je favoriete reisbestemming is {bestemming}.")
