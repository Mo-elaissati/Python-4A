# Toekenning van de variabelen: twee getallen en het quotiënt van die getallen.
n_1 = 45
n_2 = 7.5
quotiënt = n_1 / n_2

# De uitkomst wordt in een volzin d.m.v. de f-string naar de uitvoer gestuurd.
print(f"De uitkomst van de deling is {quotiënt}.")
