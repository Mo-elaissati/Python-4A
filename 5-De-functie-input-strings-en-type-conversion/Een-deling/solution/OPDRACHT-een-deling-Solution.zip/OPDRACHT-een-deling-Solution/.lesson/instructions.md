# OPDRACHT - een deling

In deze opdracht deel je twee getallen door elkaar en stuur je de uitkomst in een stringwaarde naar de uitvoer.

## Probleemstelling
Je wil twee getallen delen door elkaar en de uitkomst in een f-string naar de uitvoer sturen.

### Stappenplan
  1. Maak twee variabelen aan met de naam *n_1* en *n_2*.
  2. Je kent de waarde 45 toe aan de eerste variabele.
  3. Je kent de waarde 7.5 toe aan de tweede variabele.
  4. Maak een derde variabele aan waarin je de uitkomst van de deling berekent.
  5. Stuur een f-string naar de uitvoer. Deze heeft de volgende structuur: 'De uitkomst van de deling is *uitkomst*.'. Let goed op de plaatsing van leestekens en spaties.
  6. Klik op **submit**.

### Voorbeeld uitvoer
*Onderstaand voorbeeld geeft weer wat er **exact** in de uitvoer moet verschijnen.*
```python
"De uitkomst van de deling is 6."
```