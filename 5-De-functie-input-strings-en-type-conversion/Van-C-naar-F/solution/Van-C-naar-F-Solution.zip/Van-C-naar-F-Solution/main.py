# Vraag de gebruiker om invoer
cel = float(input("Geef een temperatuur in graden Celsius: "))

# Bereken het aantal graden Farenheit
far = (cel * 9/5) + 32

# Stuur de uitkomst naar de uitvoer in een volzin.
print(f"{cel} graden Celsius staat gelijk aan {far} graden Farenheit.")