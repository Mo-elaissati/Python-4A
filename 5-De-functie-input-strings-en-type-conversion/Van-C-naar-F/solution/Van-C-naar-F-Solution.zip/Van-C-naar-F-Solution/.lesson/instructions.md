# Van C naar F
Je schrijft een programma dat de temperatuur in graden Celsius omzet naar de temperatuur in graden Farenheit. Je maakt gebruik van de input- en printfunctie, variabelen en de f-string.

Je schrijft een programma dat het volgende realiseert:
1. **Input**: vraag aan de gebruiker om een temperatuur in graden Celsius in te geven. Ken deze waarde toe aan een variabele.
2. **Berekeningen**: zet de temperatuur in Celsius om in Farenheit met de volgende formule: Farenheit = (Celsius * 9/5) + 32.
3. **Output**: toon in de uitvoer de omgezette temperatuur in graden Farenheit.

## Een voorbeeld van de output
```cli
Geef een temperatuur in graden Celsius: 25
25.0 graden Celsius staat gelijk aan 77.0 graden Farenheit.
```

## Criteria
- Gebruik correcte benamingen voor je variabelen.
- Maak gebruik van *type conversion* om het inputgegeven om te zetten naar een float.
- Bereken met behulp van de gegeven formule de correcte temperatuur in Farenheit. Ken deze berekening toe in een nieuwe variabele.
- Test je programma meerdere keren met verschillende getallen in de invoer.